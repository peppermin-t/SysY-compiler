package formats;

public abstract class MCode {
    public abstract void print();
}
